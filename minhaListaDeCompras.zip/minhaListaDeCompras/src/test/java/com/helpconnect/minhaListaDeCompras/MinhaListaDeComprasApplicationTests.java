package com.helpconnect.minhaListaDeCompras;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinhaListaDeComprasApplicationTests {

	@Test
	void contextLoads() {
	}

}
