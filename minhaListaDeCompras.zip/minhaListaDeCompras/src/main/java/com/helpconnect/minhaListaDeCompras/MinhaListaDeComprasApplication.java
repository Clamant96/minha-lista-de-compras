package com.helpconnect.minhaListaDeCompras;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinhaListaDeComprasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinhaListaDeComprasApplication.class, args);
	}

}
